package edu.sabanciuniv.hotelbookingapp.model.enums;

public enum PaymentMethod {
    CREDIT_CARD,
    DEBIT_CARD,
    PAYPAL
}
