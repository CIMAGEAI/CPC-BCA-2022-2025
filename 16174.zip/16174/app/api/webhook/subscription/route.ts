export const dynamic = 'force-dynamic'


export async function POST() {
    try {
        
    } catch (error) {
        console.log(error)
    }
}