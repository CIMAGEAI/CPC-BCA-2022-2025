import React from 'react'
import ThemePreview from './_components/ThemePreview'

const page = () => {
  return (
    <ThemePreview />
  )
}

export default page
