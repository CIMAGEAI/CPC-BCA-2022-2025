import React from 'react'

const CreatePageSkeleton = () => {
  return (
    <div>
        {/* WIP:: Make a good skeleton */}
      Loading
    </div>
  )
}

export default CreatePageSkeleton
