// otp.controller.js
// otp.controller.js
import twilio from "twilio";
import dotenv from "dotenv";
dotenv.config();

const client = new twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

// In-memory store for OTPs (phone => { otp, expiresAt })
const otpStore = new Map();

export const sendOTP = async (req, res) => {
  const { phone } = req.body;
  if (!phone)
    return res.status(400).json({ error: "Phone number is required" });

  const otp = Math.floor(100000 + Math.random() * 900000).toString();

  try {
    await client.messages.create({
      body: `Your OTP is ${otp}`,
      to: phone,
      from: process.env.TWILIO_PHONE_NUMBER,
    });

    otpStore.set(phone, {
      otp,
      expiresAt: Date.now() + 5 * 60 * 1000, // 5 minutes expiry
    });

    res.json({ success: true, message: "OTP sent successfully" });
  } catch (err) {
    res.status(500).json({ error: "Failed to send OTP", details: err.message });
  }
};

export const verifyOTP = (req, res) => {
  const { phone, otp } = req.body;

  if (!otpStore.has(phone))
    return res.status(400).json({ error: "No OTP sent to this number" });

  const { otp: validOtp, expiresAt } = otpStore.get(phone);

  if (Date.now() > expiresAt)
    return res.status(400).json({ error: "OTP expired" });

  if (otp !== validOtp)
    return res.status(400).json({ error: "Invalid OTP" });

  otpStore.delete(phone); // OTP verified, clean up

  res.json({ success: true, message: "Phone number verified successfully" });
};
