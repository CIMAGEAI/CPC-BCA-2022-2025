import express from "express";
const router = express.Router();
import{ sendOTP, verifyOTP } from "../controllers/otp.controller.js";

router.route("/send-otp", sendOTP);
router.route("/verify-otp", verifyOTP);

export default router;
