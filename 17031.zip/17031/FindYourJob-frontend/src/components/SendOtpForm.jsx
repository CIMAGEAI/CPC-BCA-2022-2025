import React, { useState } from "react";
import axios from "axios";

function SendOtpForm({ onOtpSent }) {
  const [phone, setPhone] = useState("");

  const handleSendOtp = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/otp/send-otp", { phone });
      alert(res.data.message);
      onOtpSent(phone);
    } catch (error) {
      alert(error.response.data.error || "Failed to send OTP");
    }
  };

  return (
    <form onSubmit={handleSendOtp}>
      <input
        type="tel"
        placeholder="Enter mobile number"
        value={phone}
        onChange={(e) => setPhone(e.target.value)}
        required
      />
      <button type="submit">Send OTP</button>
    </form>
  );
}

export default SendOtpForm;
