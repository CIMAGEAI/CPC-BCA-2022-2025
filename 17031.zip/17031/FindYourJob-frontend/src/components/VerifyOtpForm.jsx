import React, { useState } from "react";
import axios from "axios";

function VerifyOtpForm({ phone }) {
  const [otp, setOtp] = useState("");

  const handleVerifyOtp = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/otp/verify-otp", { phone, otp });
      alert(res.data.message);
    } catch (error) {
      alert(error.response.data.error || "OTP verification failed");
    }
  };

  return (
    <form onSubmit={handleVerifyOtp}>
      <input
        type="text"
        placeholder="Enter OTP"
        value={otp}
        onChange={(e) => setOtp(e.target.value)}
        required
      />
      <button type="submit">Verify OTP</button>
    </form>
  );
}

export default VerifyOtpForm;
