import React, { useState } from "react";
import SendOtpForm from "./SendOtpForm";
import VerifyOtpForm from "./VerifyOtpForm";

function PhoneVerification() {
  const [phone, setPhone] = useState("");
  const [otpSent, setOtpSent] = useState(false);

  return (
    <div>
      {!otpSent ? (
        <SendOtpForm onOtpSent={(phoneNumber) => {
          setPhone(phoneNumber);
          setOtpSent(true);
        }} />
      ) : (
        <VerifyOtpForm phone={phone} />
      )}
    </div>
  );
}

export default PhoneVerification;
