(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_b4d74a70._.js",
  "static/chunks/_b4c6398a._.js"
],
    source: "dynamic"
});
