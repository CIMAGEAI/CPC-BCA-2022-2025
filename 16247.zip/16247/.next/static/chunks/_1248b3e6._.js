(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/action/data:3e8397 [app-client] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"00c1f363577fba192d231fd653a1b5b5bf5ce34087":"getAdminStats"},"action/admin.actions.ts",""] */ __turbopack_context__.s({
    "getAdminStats": (()=>getAdminStats)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var getAdminStats = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("00c1f363577fba192d231fd653a1b5b5bf5ce34087", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getAdminStats"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWRtaW4uYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzZXJ2ZXJcIjtcclxuXHJcbmltcG9ydCB7IGNvbm5lY3RUb0RCIH0gZnJvbSBcIkAvbGliL2RiXCI7XHJcbmltcG9ydCB7IFVzZXIgfSBmcm9tIFwiQC9tb2RlbHMvdXNlclwiO1xyXG5pbXBvcnQgeyBVc2VyQ2xpZW50LCBSZWNlbnRVc2VyIH0gZnJvbSBcIkAvdHlwZXMvYWRtaW5Vc2VyXCI7XHJcblxyXG4vLyDinIUgR2V0IGFsbCB1c2VycyB3aXRoIF9pZCBhcyBzdHJpbmdcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFsbFVzZXJzKCk6IFByb21pc2U8VXNlckNsaWVudFtdPiB7XHJcbiAgYXdhaXQgY29ubmVjdFRvREIoKTtcclxuXHJcbiAgY29uc3QgdXNlcnMgPSBhd2FpdCBVc2VyLmZpbmQoeyByb2xlOiBcInVzZXJcIiB9KVxyXG4gICAgLnNlbGVjdChcIm5hbWUgZW1haWwgX2lkXCIpXHJcbiAgICAubGVhbigpO1xyXG5cclxuICByZXR1cm4gdXNlcnMubWFwKCh1c2VyKSA9PiAoe1xyXG4gICAgX2lkOiB1c2VyLl9pZC50b1N0cmluZygpLFxyXG4gICAgbmFtZTogdXNlci5uYW1lLFxyXG4gICAgZW1haWw6IHVzZXIuZW1haWwsXHJcbiAgfSkpO1xyXG59XHJcblxyXG4vLyDinIUgR2V0IHNpbmdsZSB1c2VyXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRVc2VyQnlJZCh1c2VySWQ6IHN0cmluZyk6IFByb21pc2U8VXNlckNsaWVudCB8IG51bGw+IHtcclxuICBhd2FpdCBjb25uZWN0VG9EQigpO1xyXG5cclxuICBjb25zdCB1c2VyID0gYXdhaXQgVXNlci5maW5kQnlJZCh1c2VySWQpXHJcbiAgICAuc2VsZWN0KFwibmFtZSBlbWFpbCBfaWRcIilcclxuICAgIC5sZWFuKCk7XHJcblxyXG4gIGlmICghdXNlcikgcmV0dXJuIG51bGw7XHJcblxyXG4gIHJldHVybiB7XHJcbiAgICBfaWQ6IHVzZXIuX2lkLnRvU3RyaW5nKCksXHJcbiAgICBuYW1lOiB1c2VyLm5hbWUsXHJcbiAgICBlbWFpbDogdXNlci5lbWFpbCxcclxuICB9O1xyXG59XHJcblxyXG4vLyDinIUgVXBkYXRlIGV4aXN0aW5nIHVzZXJcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVVzZXIoXHJcbiAgdXNlcklkOiBzdHJpbmcsXHJcbiAgZGF0YTogUGFydGlhbDx7IG5hbWU6IHN0cmluZzsgZW1haWw6IHN0cmluZyB9PlxyXG4pOiBQcm9taXNlPFVzZXJDbGllbnQgfCBudWxsPiB7XHJcbiAgYXdhaXQgY29ubmVjdFRvREIoKTtcclxuXHJcbiAgY29uc3QgdXBkYXRlZCA9IGF3YWl0IFVzZXIuZmluZEJ5SWRBbmRVcGRhdGUodXNlcklkLCBkYXRhLCB7XHJcbiAgICBuZXc6IHRydWUsXHJcbiAgfSlcclxuICAgIC5zZWxlY3QoXCJuYW1lIGVtYWlsIF9pZFwiKVxyXG4gICAgLmxlYW4oKTtcclxuXHJcbiAgaWYgKCF1cGRhdGVkKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIF9pZDogdXBkYXRlZC5faWQudG9TdHJpbmcoKSxcclxuICAgIG5hbWU6IHVwZGF0ZWQubmFtZSxcclxuICAgIGVtYWlsOiB1cGRhdGVkLmVtYWlsLFxyXG4gIH07XHJcbn1cclxuXHJcbi8vIOKchSBEZWxldGUgdXNlciBieSBJRFxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlVXNlcih1c2VySWQ6IHN0cmluZykge1xyXG4gIGF3YWl0IGNvbm5lY3RUb0RCKCk7XHJcbiAgcmV0dXJuIGF3YWl0IFVzZXIuZmluZEJ5SWRBbmREZWxldGUodXNlcklkKTtcclxufVxyXG5cclxuLy8g4pyFIEdldCBkYXNoYm9hcmQgc3RhdHNcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFkbWluU3RhdHMoKTogUHJvbWlzZTx7XHJcbiAgdG90YWxVc2VyczogbnVtYmVyO1xyXG4gIHRvdGFsQWRtaW5zOiBudW1iZXI7XHJcbiAgcmVjZW50VXNlcnM6IFJlY2VudFVzZXJbXTtcclxufT4ge1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBjb25uZWN0VG9EQigpO1xyXG5cclxuICAgIGNvbnN0IHRvdGFsVXNlcnMgPSBhd2FpdCBVc2VyLmNvdW50RG9jdW1lbnRzKHsgcm9sZTogXCJ1c2VyXCIgfSk7XHJcbiAgICBjb25zdCB0b3RhbEFkbWlucyA9IGF3YWl0IFVzZXIuY291bnREb2N1bWVudHMoeyByb2xlOiBcImFkbWluXCIgfSk7XHJcblxyXG4gICAgY29uc3QgcmVjZW50VXNlcnNSYXcgPSBhd2FpdCBVc2VyLmZpbmQoeyByb2xlOiBcInVzZXJcIiB9KVxyXG4gICAgICAuc29ydCh7IGNyZWF0ZWRBdDogLTEgfSlcclxuICAgICAgLmxpbWl0KDUpXHJcbiAgICAgIC5zZWxlY3QoXCJuYW1lIGVtYWlsIGNyZWF0ZWRBdCBfaWRcIilcclxuICAgICAgLmxlYW4oKTtcclxuXHJcbiAgICBjb25zdCByZWNlbnRVc2VyczogUmVjZW50VXNlcltdID0gcmVjZW50VXNlcnNSYXcubWFwKCh1c2VyKSA9PiAoe1xyXG4gICAgICBfaWQ6IHVzZXIuX2lkLnRvU3RyaW5nKCksXHJcbiAgICAgIG5hbWU6IHVzZXIubmFtZSxcclxuICAgICAgZW1haWw6IHVzZXIuZW1haWwsXHJcbiAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUodXNlci5jcmVhdGVkQXQpLnRvSVNPU3RyaW5nKCksIC8vIOKchSBjb252ZXJ0IHRvIHN0cmluZ1xyXG4gICAgfSkpO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHRvdGFsVXNlcnMsXHJcbiAgICAgIHRvdGFsQWRtaW5zLFxyXG4gICAgICByZWNlbnRVc2VycyxcclxuICAgIH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBhZG1pbiBzdGF0czpcIiwgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgdG90YWxVc2VyczogMCxcclxuICAgICAgdG90YWxBZG1pbnM6IDAsXHJcbiAgICAgIHJlY2VudFVzZXJzOiBbXSxcclxuICAgIH07XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOFJBbUVzQiJ9
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/action/data:e48168 [app-client] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"00d28b445dafaf5a553c65b7fea6698de310828355":"getAllUsers"},"action/admin.actions.ts",""] */ __turbopack_context__.s({
    "getAllUsers": (()=>getAllUsers)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var getAllUsers = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("00d28b445dafaf5a553c65b7fea6698de310828355", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getAllUsers"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWRtaW4uYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzZXJ2ZXJcIjtcclxuXHJcbmltcG9ydCB7IGNvbm5lY3RUb0RCIH0gZnJvbSBcIkAvbGliL2RiXCI7XHJcbmltcG9ydCB7IFVzZXIgfSBmcm9tIFwiQC9tb2RlbHMvdXNlclwiO1xyXG5pbXBvcnQgeyBVc2VyQ2xpZW50LCBSZWNlbnRVc2VyIH0gZnJvbSBcIkAvdHlwZXMvYWRtaW5Vc2VyXCI7XHJcblxyXG4vLyDinIUgR2V0IGFsbCB1c2VycyB3aXRoIF9pZCBhcyBzdHJpbmdcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFsbFVzZXJzKCk6IFByb21pc2U8VXNlckNsaWVudFtdPiB7XHJcbiAgYXdhaXQgY29ubmVjdFRvREIoKTtcclxuXHJcbiAgY29uc3QgdXNlcnMgPSBhd2FpdCBVc2VyLmZpbmQoeyByb2xlOiBcInVzZXJcIiB9KVxyXG4gICAgLnNlbGVjdChcIm5hbWUgZW1haWwgX2lkXCIpXHJcbiAgICAubGVhbigpO1xyXG5cclxuICByZXR1cm4gdXNlcnMubWFwKCh1c2VyKSA9PiAoe1xyXG4gICAgX2lkOiB1c2VyLl9pZC50b1N0cmluZygpLFxyXG4gICAgbmFtZTogdXNlci5uYW1lLFxyXG4gICAgZW1haWw6IHVzZXIuZW1haWwsXHJcbiAgfSkpO1xyXG59XHJcblxyXG4vLyDinIUgR2V0IHNpbmdsZSB1c2VyXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRVc2VyQnlJZCh1c2VySWQ6IHN0cmluZyk6IFByb21pc2U8VXNlckNsaWVudCB8IG51bGw+IHtcclxuICBhd2FpdCBjb25uZWN0VG9EQigpO1xyXG5cclxuICBjb25zdCB1c2VyID0gYXdhaXQgVXNlci5maW5kQnlJZCh1c2VySWQpXHJcbiAgICAuc2VsZWN0KFwibmFtZSBlbWFpbCBfaWRcIilcclxuICAgIC5sZWFuKCk7XHJcblxyXG4gIGlmICghdXNlcikgcmV0dXJuIG51bGw7XHJcblxyXG4gIHJldHVybiB7XHJcbiAgICBfaWQ6IHVzZXIuX2lkLnRvU3RyaW5nKCksXHJcbiAgICBuYW1lOiB1c2VyLm5hbWUsXHJcbiAgICBlbWFpbDogdXNlci5lbWFpbCxcclxuICB9O1xyXG59XHJcblxyXG4vLyDinIUgVXBkYXRlIGV4aXN0aW5nIHVzZXJcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVVzZXIoXHJcbiAgdXNlcklkOiBzdHJpbmcsXHJcbiAgZGF0YTogUGFydGlhbDx7IG5hbWU6IHN0cmluZzsgZW1haWw6IHN0cmluZyB9PlxyXG4pOiBQcm9taXNlPFVzZXJDbGllbnQgfCBudWxsPiB7XHJcbiAgYXdhaXQgY29ubmVjdFRvREIoKTtcclxuXHJcbiAgY29uc3QgdXBkYXRlZCA9IGF3YWl0IFVzZXIuZmluZEJ5SWRBbmRVcGRhdGUodXNlcklkLCBkYXRhLCB7XHJcbiAgICBuZXc6IHRydWUsXHJcbiAgfSlcclxuICAgIC5zZWxlY3QoXCJuYW1lIGVtYWlsIF9pZFwiKVxyXG4gICAgLmxlYW4oKTtcclxuXHJcbiAgaWYgKCF1cGRhdGVkKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIF9pZDogdXBkYXRlZC5faWQudG9TdHJpbmcoKSxcclxuICAgIG5hbWU6IHVwZGF0ZWQubmFtZSxcclxuICAgIGVtYWlsOiB1cGRhdGVkLmVtYWlsLFxyXG4gIH07XHJcbn1cclxuXHJcbi8vIOKchSBEZWxldGUgdXNlciBieSBJRFxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlVXNlcih1c2VySWQ6IHN0cmluZykge1xyXG4gIGF3YWl0IGNvbm5lY3RUb0RCKCk7XHJcbiAgcmV0dXJuIGF3YWl0IFVzZXIuZmluZEJ5SWRBbmREZWxldGUodXNlcklkKTtcclxufVxyXG5cclxuLy8g4pyFIEdldCBkYXNoYm9hcmQgc3RhdHNcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFkbWluU3RhdHMoKTogUHJvbWlzZTx7XHJcbiAgdG90YWxVc2VyczogbnVtYmVyO1xyXG4gIHRvdGFsQWRtaW5zOiBudW1iZXI7XHJcbiAgcmVjZW50VXNlcnM6IFJlY2VudFVzZXJbXTtcclxufT4ge1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBjb25uZWN0VG9EQigpO1xyXG5cclxuICAgIGNvbnN0IHRvdGFsVXNlcnMgPSBhd2FpdCBVc2VyLmNvdW50RG9jdW1lbnRzKHsgcm9sZTogXCJ1c2VyXCIgfSk7XHJcbiAgICBjb25zdCB0b3RhbEFkbWlucyA9IGF3YWl0IFVzZXIuY291bnREb2N1bWVudHMoeyByb2xlOiBcImFkbWluXCIgfSk7XHJcblxyXG4gICAgY29uc3QgcmVjZW50VXNlcnNSYXcgPSBhd2FpdCBVc2VyLmZpbmQoeyByb2xlOiBcInVzZXJcIiB9KVxyXG4gICAgICAuc29ydCh7IGNyZWF0ZWRBdDogLTEgfSlcclxuICAgICAgLmxpbWl0KDUpXHJcbiAgICAgIC5zZWxlY3QoXCJuYW1lIGVtYWlsIGNyZWF0ZWRBdCBfaWRcIilcclxuICAgICAgLmxlYW4oKTtcclxuXHJcbiAgICBjb25zdCByZWNlbnRVc2VyczogUmVjZW50VXNlcltdID0gcmVjZW50VXNlcnNSYXcubWFwKCh1c2VyKSA9PiAoe1xyXG4gICAgICBfaWQ6IHVzZXIuX2lkLnRvU3RyaW5nKCksXHJcbiAgICAgIG5hbWU6IHVzZXIubmFtZSxcclxuICAgICAgZW1haWw6IHVzZXIuZW1haWwsXHJcbiAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUodXNlci5jcmVhdGVkQXQpLnRvSVNPU3RyaW5nKCksIC8vIOKchSBjb252ZXJ0IHRvIHN0cmluZ1xyXG4gICAgfSkpO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHRvdGFsVXNlcnMsXHJcbiAgICAgIHRvdGFsQWRtaW5zLFxyXG4gICAgICByZWNlbnRVc2VycyxcclxuICAgIH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBhZG1pbiBzdGF0czpcIiwgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgdG90YWxVc2VyczogMCxcclxuICAgICAgdG90YWxBZG1pbnM6IDAsXHJcbiAgICAgIHJlY2VudFVzZXJzOiBbXSxcclxuICAgIH07XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiNFJBT3NCIn0=
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/action/data:4579d9 [app-client] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"40ce7619ab984705e45daf5f3b9aaeedf2f081c655":"deleteUser"},"action/admin.actions.ts",""] */ __turbopack_context__.s({
    "deleteUser": (()=>deleteUser)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var deleteUser = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40ce7619ab984705e45daf5f3b9aaeedf2f081c655", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "deleteUser"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWRtaW4uYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzZXJ2ZXJcIjtcclxuXHJcbmltcG9ydCB7IGNvbm5lY3RUb0RCIH0gZnJvbSBcIkAvbGliL2RiXCI7XHJcbmltcG9ydCB7IFVzZXIgfSBmcm9tIFwiQC9tb2RlbHMvdXNlclwiO1xyXG5pbXBvcnQgeyBVc2VyQ2xpZW50LCBSZWNlbnRVc2VyIH0gZnJvbSBcIkAvdHlwZXMvYWRtaW5Vc2VyXCI7XHJcblxyXG4vLyDinIUgR2V0IGFsbCB1c2VycyB3aXRoIF9pZCBhcyBzdHJpbmdcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFsbFVzZXJzKCk6IFByb21pc2U8VXNlckNsaWVudFtdPiB7XHJcbiAgYXdhaXQgY29ubmVjdFRvREIoKTtcclxuXHJcbiAgY29uc3QgdXNlcnMgPSBhd2FpdCBVc2VyLmZpbmQoeyByb2xlOiBcInVzZXJcIiB9KVxyXG4gICAgLnNlbGVjdChcIm5hbWUgZW1haWwgX2lkXCIpXHJcbiAgICAubGVhbigpO1xyXG5cclxuICByZXR1cm4gdXNlcnMubWFwKCh1c2VyKSA9PiAoe1xyXG4gICAgX2lkOiB1c2VyLl9pZC50b1N0cmluZygpLFxyXG4gICAgbmFtZTogdXNlci5uYW1lLFxyXG4gICAgZW1haWw6IHVzZXIuZW1haWwsXHJcbiAgfSkpO1xyXG59XHJcblxyXG4vLyDinIUgR2V0IHNpbmdsZSB1c2VyXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRVc2VyQnlJZCh1c2VySWQ6IHN0cmluZyk6IFByb21pc2U8VXNlckNsaWVudCB8IG51bGw+IHtcclxuICBhd2FpdCBjb25uZWN0VG9EQigpO1xyXG5cclxuICBjb25zdCB1c2VyID0gYXdhaXQgVXNlci5maW5kQnlJZCh1c2VySWQpXHJcbiAgICAuc2VsZWN0KFwibmFtZSBlbWFpbCBfaWRcIilcclxuICAgIC5sZWFuKCk7XHJcblxyXG4gIGlmICghdXNlcikgcmV0dXJuIG51bGw7XHJcblxyXG4gIHJldHVybiB7XHJcbiAgICBfaWQ6IHVzZXIuX2lkLnRvU3RyaW5nKCksXHJcbiAgICBuYW1lOiB1c2VyLm5hbWUsXHJcbiAgICBlbWFpbDogdXNlci5lbWFpbCxcclxuICB9O1xyXG59XHJcblxyXG4vLyDinIUgVXBkYXRlIGV4aXN0aW5nIHVzZXJcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVVzZXIoXHJcbiAgdXNlcklkOiBzdHJpbmcsXHJcbiAgZGF0YTogUGFydGlhbDx7IG5hbWU6IHN0cmluZzsgZW1haWw6IHN0cmluZyB9PlxyXG4pOiBQcm9taXNlPFVzZXJDbGllbnQgfCBudWxsPiB7XHJcbiAgYXdhaXQgY29ubmVjdFRvREIoKTtcclxuXHJcbiAgY29uc3QgdXBkYXRlZCA9IGF3YWl0IFVzZXIuZmluZEJ5SWRBbmRVcGRhdGUodXNlcklkLCBkYXRhLCB7XHJcbiAgICBuZXc6IHRydWUsXHJcbiAgfSlcclxuICAgIC5zZWxlY3QoXCJuYW1lIGVtYWlsIF9pZFwiKVxyXG4gICAgLmxlYW4oKTtcclxuXHJcbiAgaWYgKCF1cGRhdGVkKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIF9pZDogdXBkYXRlZC5faWQudG9TdHJpbmcoKSxcclxuICAgIG5hbWU6IHVwZGF0ZWQubmFtZSxcclxuICAgIGVtYWlsOiB1cGRhdGVkLmVtYWlsLFxyXG4gIH07XHJcbn1cclxuXHJcbi8vIOKchSBEZWxldGUgdXNlciBieSBJRFxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlVXNlcih1c2VySWQ6IHN0cmluZykge1xyXG4gIGF3YWl0IGNvbm5lY3RUb0RCKCk7XHJcbiAgcmV0dXJuIGF3YWl0IFVzZXIuZmluZEJ5SWRBbmREZWxldGUodXNlcklkKTtcclxufVxyXG5cclxuLy8g4pyFIEdldCBkYXNoYm9hcmQgc3RhdHNcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFkbWluU3RhdHMoKTogUHJvbWlzZTx7XHJcbiAgdG90YWxVc2VyczogbnVtYmVyO1xyXG4gIHRvdGFsQWRtaW5zOiBudW1iZXI7XHJcbiAgcmVjZW50VXNlcnM6IFJlY2VudFVzZXJbXTtcclxufT4ge1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBjb25uZWN0VG9EQigpO1xyXG5cclxuICAgIGNvbnN0IHRvdGFsVXNlcnMgPSBhd2FpdCBVc2VyLmNvdW50RG9jdW1lbnRzKHsgcm9sZTogXCJ1c2VyXCIgfSk7XHJcbiAgICBjb25zdCB0b3RhbEFkbWlucyA9IGF3YWl0IFVzZXIuY291bnREb2N1bWVudHMoeyByb2xlOiBcImFkbWluXCIgfSk7XHJcblxyXG4gICAgY29uc3QgcmVjZW50VXNlcnNSYXcgPSBhd2FpdCBVc2VyLmZpbmQoeyByb2xlOiBcInVzZXJcIiB9KVxyXG4gICAgICAuc29ydCh7IGNyZWF0ZWRBdDogLTEgfSlcclxuICAgICAgLmxpbWl0KDUpXHJcbiAgICAgIC5zZWxlY3QoXCJuYW1lIGVtYWlsIGNyZWF0ZWRBdCBfaWRcIilcclxuICAgICAgLmxlYW4oKTtcclxuXHJcbiAgICBjb25zdCByZWNlbnRVc2VyczogUmVjZW50VXNlcltdID0gcmVjZW50VXNlcnNSYXcubWFwKCh1c2VyKSA9PiAoe1xyXG4gICAgICBfaWQ6IHVzZXIuX2lkLnRvU3RyaW5nKCksXHJcbiAgICAgIG5hbWU6IHVzZXIubmFtZSxcclxuICAgICAgZW1haWw6IHVzZXIuZW1haWwsXHJcbiAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUodXNlci5jcmVhdGVkQXQpLnRvSVNPU3RyaW5nKCksIC8vIOKchSBjb252ZXJ0IHRvIHN0cmluZ1xyXG4gICAgfSkpO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHRvdGFsVXNlcnMsXHJcbiAgICAgIHRvdGFsQWRtaW5zLFxyXG4gICAgICByZWNlbnRVc2VycyxcclxuICAgIH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBhZG1pbiBzdGF0czpcIiwgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgdG90YWxVc2VyczogMCxcclxuICAgICAgdG90YWxBZG1pbnM6IDAsXHJcbiAgICAgIHJlY2VudFVzZXJzOiBbXSxcclxuICAgIH07XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiMlJBNkRzQiJ9
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/(admin)/dashboard/users/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>AdminDashboardPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$action$2f$data$3a$3e8397__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/action/data:3e8397 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$action$2f$data$3a$e48168__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/action/data:e48168 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$action$2f$data$3a$4579d9__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/action/data:4579d9 [app-client] (ecmascript) <text/javascript>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function AdminDashboardPage() {
    _s();
    const [stats, setStats] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [users, setUsers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AdminDashboardPage.useEffect": ()=>{
            async function loadDashboard() {
                setLoading(true);
                const statRes = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$action$2f$data$3a$3e8397__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getAdminStats"])();
                const userRes = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$action$2f$data$3a$e48168__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getAllUsers"])();
                setStats(statRes);
                setUsers(userRes);
                setLoading(false);
            }
            loadDashboard();
        }
    }["AdminDashboardPage.useEffect"], []);
    const handleDelete = async (id)=>{
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$action$2f$data$3a$4579d9__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["deleteUser"])(id);
        setUsers(users.filter((u)=>u._id !== id));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "p-6 bg-gray-50 min-h-screen",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-4xl font-bold mb-6 text-gray-800",
                children: "Admin Dashboard"
            }, void 0, false, {
                fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, this),
            loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-gray-600 animate-pulse",
                children: "Loading..."
            }, void 0, false, {
                fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                lineNumber: 45,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 md:grid-cols-4 gap-6 mb-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-blue-100 p-6 rounded-xl shadow",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-gray-600",
                                        children: "Total Users"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                        lineNumber: 51,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-3xl font-bold text-blue-800",
                                        children: stats?.totalUsers ?? "..."
                                    }, void 0, false, {
                                        fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                        lineNumber: 52,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                lineNumber: 50,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-green-100 p-6 rounded-xl shadow",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-gray-600",
                                        children: "Total Admins"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                        lineNumber: 57,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-3xl font-bold text-green-800",
                                        children: stats?.totalAdmins ?? "..."
                                    }, void 0, false, {
                                        fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                        lineNumber: 58,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                lineNumber: 56,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                        lineNumber: 49,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white p-6 rounded-xl shadow mb-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-xl font-semibold mb-4",
                                children: "Recent Signups"
                            }, void 0, false, {
                                fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                lineNumber: 66,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                className: "divide-y divide-gray-200",
                                children: [
                                    stats?.recentUsers.map((user)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            className: "py-3 flex justify-between items-center",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "font-medium text-gray-800",
                                                            children: user.name
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                                            lineNumber: 74,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-sm text-gray-500",
                                                            children: user.email
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                                            lineNumber: 75,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                                    lineNumber: 73,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-sm text-gray-400",
                                                    children: new Date(user.createdAt).toLocaleDateString()
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                                    lineNumber: 77,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, user._id, true, {
                                            fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                            lineNumber: 69,
                                            columnNumber: 17
                                        }, this)),
                                    stats?.recentUsers.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-gray-500",
                                        children: "No recent users"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                        lineNumber: 83,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                lineNumber: 67,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                        lineNumber: 65,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white p-6 rounded-xl shadow",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-xl font-semibold mb-4",
                                children: "All Users"
                            }, void 0, false, {
                                fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                lineNumber: 90,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                className: "w-full text-sm text-left border",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                        className: "bg-gray-100",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                    className: "p-3",
                                                    children: "Name"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                                    lineNumber: 94,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                    className: "p-3",
                                                    children: "Email"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                                    lineNumber: 95,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                    className: "p-3",
                                                    children: "Actions"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                                    lineNumber: 96,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                            lineNumber: 93,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                        lineNumber: 92,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                        children: [
                                            users.map((user)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                    className: "border-t",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "p-3",
                                                            children: user.name
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                                            lineNumber: 102,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "p-3",
                                                            children: user.email
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                                            lineNumber: 103,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "p-3",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                onClick: ()=>handleDelete(user._id),
                                                                className: "text-red-600 hover:underline",
                                                                children: "Delete"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                                                lineNumber: 105,
                                                                columnNumber: 23
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                                            lineNumber: 104,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, user._id, true, {
                                                    fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                                    lineNumber: 101,
                                                    columnNumber: 19
                                                }, this)),
                                            users.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    colSpan: 3,
                                                    className: "text-center p-4 text-gray-500 italic",
                                                    children: "No users found."
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                                    lineNumber: 116,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                                lineNumber: 115,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                        lineNumber: 99,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                                lineNumber: 91,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
                        lineNumber: 89,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(admin)/dashboard/users/page.tsx",
        lineNumber: 39,
        columnNumber: 5
    }, this);
}
_s(AdminDashboardPage, "CD25TYYCoB72zF94cwPLtlDiGdI=");
_c = AdminDashboardPage;
var _c;
__turbopack_context__.k.register(_c, "AdminDashboardPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=_1248b3e6._.js.map