(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__9d126714._.css",
  "static/chunks/node_modules_sonner_dist_index_mjs_1c0de420._.js"
],
    source: "dynamic"
});
