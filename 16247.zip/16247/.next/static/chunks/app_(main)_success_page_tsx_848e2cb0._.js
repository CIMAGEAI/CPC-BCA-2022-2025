(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_0d21c92d._.js",
  "static/chunks/app_(main)_success_page_tsx_cde7d029._.js"
],
    source: "dynamic"
});
