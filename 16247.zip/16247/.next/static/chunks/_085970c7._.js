(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/components/productCard.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$cart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingCart$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shopping-cart.js [app-client] (ecmascript) <export default as ShoppingCart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$cartStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/stores/cartStore.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
const ProductCard = ({ product })=>{
    _s();
    const addToCart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$cartStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "ProductCard.useCartStore[addToCart]": (state)=>state.addToCart
    }["ProductCard.useCartStore[addToCart]"]);
    const imageUrl = product.attributeValues?.p_image?.value?.downloadLink || '';
    const title = product.attributeValues?.p_title?.value || product.localizeInfos?.title || 'Untitled Product';
    const price = typeof product.attributeValues?.p_price?.value === 'string' ? parseFloat(product.attributeValues.p_price.value) : product.attributeValues?.p_price?.value || 0;
    const description = product.attributeValues?.p_description?.value?.[0]?.htmlValue || '';
    const handleAddToCart = ()=>{
        addToCart({
            id: typeof product.id === 'string' ? Number(product.id) : product.id,
            name: title,
            price: price,
            quantity: 1,
            image: imageUrl
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"])('Added to Cart', {
            description: `${title} has been added to your cart.`,
            duration: 4000
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "group relative h-full flex flex-col rounded-lg shadow-lg border border-gray-200 bg-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: `/product/${product.id}`,
                className: "relative w-full pt-[100%] bg-gray-50 overflow-hidden",
                children: imageUrl.startsWith('data:image') ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                    src: imageUrl,
                    alt: title,
                    className: "absolute inset-0 w-full h-full object-contain transition-transform duration-300 group-hover:scale-105 border-b border-gray-200"
                }, void 0, false, {
                    fileName: "[project]/components/productCard.tsx",
                    lineNumber: 49,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: imageUrl,
                    alt: title,
                    fill: true,
                    className: "object-contain transition-transform duration-300 group-hover:scale-105 border-b border-gray-200"
                }, void 0, false, {
                    fileName: "[project]/components/productCard.tsx",
                    lineNumber: 55,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/productCard.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-4 flex-grow",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: `/product/${product.id}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-xl mb-2 text-gray-700 group-hover:text-purple-500 transition-colors duration-300 line-clamp-1",
                            children: title
                        }, void 0, false, {
                            fileName: "[project]/components/productCard.tsx",
                            lineNumber: 66,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/productCard.tsx",
                        lineNumber: 65,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-gray-500 line-clamp-2 text-sm mb-2",
                        dangerouslySetInnerHTML: {
                            __html: description
                        }
                    }, void 0, false, {
                        fileName: "[project]/components/productCard.tsx",
                        lineNumber: 71,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-800 font-semibold text-lg",
                        children: [
                            "₹",
                            price.toFixed(2)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/productCard.tsx",
                        lineNumber: 76,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/productCard.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                    className: "w-full bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 hover:from-purple-600 hover:via-pink-600 hover:to-red-600 text-white font-semibold",
                    onClick: handleAddToCart,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$cart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingCart$3e$__["ShoppingCart"], {
                            className: "w-5 h-5 mr-2"
                        }, void 0, false, {
                            fileName: "[project]/components/productCard.tsx",
                            lineNumber: 86,
                            columnNumber: 11
                        }, this),
                        "Add to Cart"
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/productCard.tsx",
                    lineNumber: 82,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/productCard.tsx",
                lineNumber: 81,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/productCard.tsx",
        lineNumber: 46,
        columnNumber: 5
    }, this);
};
_s(ProductCard, "I6LlfSAQPmwjG9lRquzs4Z4Ovt4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$stores$2f$cartStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c = ProductCard;
const __TURBOPACK__default__export__ = ProductCard;
var _c;
__turbopack_context__.k.register(_c, "ProductCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/productCatalog.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$productCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/productCard.tsx [app-client] (ecmascript)");
;
;
const ProductCatalog = ({ title, products })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "mb-12",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-3xl font-bold mb-8 bg-gradient-to-r from-purple-600 via-pink-500 to-red-500 bg-clip-text text-transparent",
                children: title
            }, void 0, false, {
                fileName: "[project]/components/productCatalog.tsx",
                lineNumber: 31,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8",
                children: products?.map((product)=>{
                    const price = typeof product.price === 'string' ? parseFloat(product.price) : product.price;
                    const image = product.image || product.attributeValues?.p_image?.value?.downloadLink || '';
                    const p_title = product.attributeValues?.p_title?.value || product.title || product.localizeInfos?.title || 'Untitled Product';
                    const p_price = typeof product.attributeValues?.p_price?.value === 'string' ? parseFloat(product.attributeValues.p_price.value) : product.attributeValues?.p_price?.value ?? price;
                    const p_description = product.attributeValues?.p_description?.value?.map((desc)=>({
                            htmlValue: desc
                        })) ?? [];
                    const transformedProduct = {
                        id: product.id,
                        localizeInfos: {
                            title: product.localizeInfos?.title || ''
                        },
                        price,
                        attributeValues: {
                            p_description: {
                                value: p_description
                            },
                            p_price: {
                                value: p_price
                            },
                            p_image: {
                                value: {
                                    downloadLink: image
                                }
                            },
                            p_title: {
                                value: p_title
                            }
                        }
                    };
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$productCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        product: transformedProduct
                    }, product.id, false, {
                        fileName: "[project]/components/productCatalog.tsx",
                        lineNumber: 75,
                        columnNumber: 18
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/components/productCatalog.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/productCatalog.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this);
};
_c = ProductCatalog;
const __TURBOPACK__default__export__ = ProductCatalog;
var _c;
__turbopack_context__.k.register(_c, "ProductCatalog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/action/data:059110 [app-client] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"7f7e7a519f1d6662beab7ffa92bd2e13c74106aefd":"getProductsByCategory"},"action/product.actions.ts",""] */ __turbopack_context__.s({
    "getProductsByCategory": (()=>getProductsByCategory)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var getProductsByCategory = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("7f7e7a519f1d6662beab7ffa92bd2e13c74106aefd", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getProductsByCategory"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vcHJvZHVjdC5hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xyXG5cclxuaW1wb3J0IHsgY29ubmVjdFRvREIgfSBmcm9tIFwiQC9saWIvZGJcIjtcclxuaW1wb3J0IHsgUHJvZHVjdCB9IGZyb20gXCJAL21vZGVscy9wcm9kdWN0c1wiO1xyXG5pbXBvcnQgeyBVc2VyIH0gZnJvbSBcIkAvbW9kZWxzL3VzZXJcIjtcclxuaW1wb3J0IHsgY29va2llcyB9IGZyb20gXCJuZXh0L2hlYWRlcnNcIjtcclxuaW1wb3J0IGp3dCBmcm9tIFwianNvbndlYnRva2VuXCI7XHJcblxyXG4vLyBDb21tb24gdHlwZSBmb3IgY2xpZW50LXNhZmUgcHJvZHVjdHNcclxuZXhwb3J0IHR5cGUgUHJvZHVjdElucHV0ID0ge1xyXG4gIGlkOiBzdHJpbmc7XHJcbiAgdGl0bGU6IHN0cmluZztcclxuICBkZXNjcmlwdGlvbjogc3RyaW5nO1xyXG4gIHByaWNlOiBudW1iZXI7XHJcbiAgaW1hZ2U6IHN0cmluZztcclxufTtcclxuXHJcbi8vIERlY29kZWQgSldUIFRva2VuIFR5cGVcclxuaW50ZXJmYWNlIERlY29kZWRUb2tlbiB7XHJcbiAgX2lkOiBzdHJpbmc7XHJcbiAgcm9sZTogc3RyaW5nO1xyXG4gIGVtYWlsOiBzdHJpbmc7XHJcbn1cclxuXHJcbi8vIPCflJAgSldULWJhc2VkIGF1dGhlbnRpY2F0aW9uIChmb3IgYWRtaW4gZW5kcG9pbnRzKVxyXG5jb25zdCBnZXRDdXJyZW50VXNlciA9IGFzeW5jICgpOiBQcm9taXNlPERlY29kZWRUb2tlbiB8IG51bGw+ID0+IHtcclxuICBjb25zdCB0b2tlbiA9IChhd2FpdCBjb29raWVzKCkpLmdldChcImFjY2Vzc1Rva2VuXCIpPy52YWx1ZTtcclxuICBpZiAoIXRva2VuIHx8ICFwcm9jZXNzLmVudi5BQ0NFU1NfU0VDUkVUKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRlY29kZWQgPSBqd3QudmVyaWZ5KHRva2VuLCBwcm9jZXNzLmVudi5BQ0NFU1NfU0VDUkVUKSBhcyBEZWNvZGVkVG9rZW47XHJcbiAgICByZXR1cm4gZGVjb2RlZDtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxufTtcclxuXHJcbi8vIOKchSBDcmVhdGUgUHJvZHVjdCAoU2VsbGVyIG9ubHkpXHJcbmV4cG9ydCBjb25zdCBjcmVhdGVQcm9kdWN0ID0gYXN5bmMgKGZvcm1EYXRhOiBGb3JtRGF0YSkgPT4ge1xyXG4gIGNvbnN0IGFsbENvb2tpZXMgPSBhd2FpdCBjb29raWVzKCk7XHJcbiAgY29uc3Qgcm9sZSA9IGFsbENvb2tpZXMuZ2V0KFwidXNlclJvbGVcIik/LnZhbHVlO1xyXG4gIGNvbnN0IHNlbGxlcklkID0gYWxsQ29va2llcy5nZXQoXCJpZFwiKT8udmFsdWU7XHJcbmlmICghc2VsbGVySWQgfHwgKHJvbGUgIT09IFwic2VsbGVyXCIgJiYgcm9sZSAhPT0gXCJhZG1pblwiKSkge1xyXG4gIHRocm93IG5ldyBFcnJvcihcIlVuYXV0aG9yaXplZDogT25seSBzZWxsZXJzIG9yIGFkbWlucyBjYW4gY3JlYXRlIHByb2R1Y3RzLlwiKTtcclxufVxyXG5cclxuICBjb25zdCB0aXRsZSA9IGZvcm1EYXRhLmdldChcInRpdGxlXCIpIGFzIHN0cmluZztcclxuICBjb25zdCBwcmljZSA9IE51bWJlcihmb3JtRGF0YS5nZXQoXCJwcmljZVwiKSk7XHJcbiAgY29uc3QgZGVzY3JpcHRpb24gPSBmb3JtRGF0YS5nZXQoXCJkZXNjcmlwdGlvblwiKSBhcyBzdHJpbmc7XHJcbiAgY29uc3QgY2F0ZWdvcnkgPSBmb3JtRGF0YS5nZXQoXCJjYXRlZ29yeVwiKSBhcyBzdHJpbmc7XHJcbiAgY29uc3QgZmlsZSA9IGZvcm1EYXRhLmdldChcImltYWdlXCIpIGFzIEZpbGU7XHJcblxyXG4gIGNvbnN0IGJ1ZmZlciA9IGF3YWl0IGZpbGUuYXJyYXlCdWZmZXIoKTtcclxuICBjb25zdCBiYXNlNjQgPSBCdWZmZXIuZnJvbShidWZmZXIpLnRvU3RyaW5nKFwiYmFzZTY0XCIpO1xyXG4gIGNvbnN0IGltYWdlID0gYGRhdGE6JHtmaWxlLnR5cGV9O2Jhc2U2NCwke2Jhc2U2NH1gO1xyXG5cclxuICBhd2FpdCBjb25uZWN0VG9EQigpO1xyXG5cclxuICBjb25zdCBwcm9kdWN0ID0gbmV3IFByb2R1Y3QoeyB0aXRsZSwgcHJpY2UsIGRlc2NyaXB0aW9uLCBjYXRlZ29yeSwgaW1hZ2UsIHNlbGxlcklkIH0pO1xyXG4gIGF3YWl0IHByb2R1Y3Quc2F2ZSgpO1xyXG5cclxuICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcbn07XHJcblxyXG4vLyDinIUgU2VsbGVyOiBHZXQgVGhlaXIgUHJvZHVjdHNcclxuZXhwb3J0IGNvbnN0IGdldFNlbGxlclByb2R1Y3RzID0gYXN5bmMgKCkgPT4ge1xyXG4gIGNvbnN0IGFsbENvb2tpZXMgPSBhd2FpdCBjb29raWVzKCk7XHJcbiAgY29uc3Qgcm9sZSA9IGFsbENvb2tpZXMuZ2V0KFwidXNlclJvbGVcIik/LnZhbHVlO1xyXG4gIGNvbnN0IHNlbGxlcklkID0gYWxsQ29va2llcy5nZXQoXCJpZFwiKT8udmFsdWU7XHJcblxyXG4gIGlmICghcm9sZSB8fCAhc2VsbGVySWQpIHtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIlVuYXV0aG9yaXplZFwiKTtcclxuICB9XHJcblxyXG4gIGF3YWl0IGNvbm5lY3RUb0RCKCk7XHJcblxyXG4gIGNvbnN0IHF1ZXJ5ID0gcm9sZSA9PT0gXCJhZG1pblwiID8ge30gOiB7IHNlbGxlcklkIH07XHJcblxyXG4gIGNvbnN0IHByb2R1Y3RzID0gYXdhaXQgUHJvZHVjdC5maW5kKHF1ZXJ5KVxyXG4gICAgLnBvcHVsYXRlKFwic2VsbGVySWRcIiwgXCJuYW1lIGVtYWlsXCIpXHJcbiAgICAuc29ydCh7IGNyZWF0ZWRBdDogLTEgfSlcclxuICAgIC5sZWFuKCk7XHJcblxyXG4gIHJldHVybiBwcm9kdWN0cztcclxufTtcclxuXHJcbi8vIOKchSBBZG1pbiBvbmx5OiBHZXQgQWxsIFByb2R1Y3RzXHJcbmV4cG9ydCBjb25zdCBnZXRBbGxQcm9kdWN0cyA9IGFzeW5jICgpID0+IHtcclxuICBjb25zdCB1c2VyID0gYXdhaXQgZ2V0Q3VycmVudFVzZXIoKTtcclxuICBpZiAoIXVzZXIgfHwgdXNlci5yb2xlICE9PSBcImFkbWluXCIpIHtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIlVuYXV0aG9yaXplZDogQWRtaW5zIG9ubHkuXCIpO1xyXG4gIH1cclxuXHJcbiAgYXdhaXQgY29ubmVjdFRvREIoKTtcclxuXHJcbiAgcmV0dXJuIGF3YWl0IFByb2R1Y3QuZmluZCgpXHJcbiAgICAucG9wdWxhdGUoXCJzZWxsZXJJZFwiLCBcIm5hbWUgZW1haWxcIilcclxuICAgIC5zb3J0KHsgY3JlYXRlZEF0OiAtMSB9KVxyXG4gICAgLmxlYW4oKTtcclxufTtcclxuXHJcbi8vIOKchSBQdWJsaWM6IEdldCBQcm9kdWN0cyBieSBDYXRlZ29yeSAoQ2xpZW50IHVzZXMgdGhpcylcclxuZXhwb3J0IGNvbnN0IGdldFByb2R1Y3RzQnlDYXRlZ29yeSA9IGFzeW5jIChjYXRlZ29yeTogc3RyaW5nKTogUHJvbWlzZTxQcm9kdWN0SW5wdXRbXT4gPT4ge1xyXG4gIGF3YWl0IGNvbm5lY3RUb0RCKCk7XHJcblxyXG4gIGNvbnN0IHByb2R1Y3RzID0gYXdhaXQgUHJvZHVjdC5maW5kKHsgY2F0ZWdvcnkgfSkuc29ydCh7IGNyZWF0ZWRBdDogLTEgfSkubGVhbigpO1xyXG5cclxuICByZXR1cm4gcHJvZHVjdHMubWFwKChwcm9kdWN0KSA9PiB7XHJcbiAgICBjb25zdCBpZCA9IHByb2R1Y3QuX2lkPy50b1N0cmluZz8uKCkgfHwgXCJ1bmtub3duXCI7XHJcblxyXG4gICAgY29uc3QgdGl0bGUgPSBwcm9kdWN0LnRpdGxlIHx8IHByb2R1Y3QuYXR0cmlidXRlVmFsdWVzPy5wX3RpdGxlPy52YWx1ZSB8fCBcIlVudGl0bGVkXCI7XHJcblxyXG4gICAgY29uc3QgZGVzY3JpcHRpb24gPSBwcm9kdWN0LmRlc2NyaXB0aW9uXHJcbiAgICAgID8/IChBcnJheS5pc0FycmF5KHByb2R1Y3QuYXR0cmlidXRlVmFsdWVzPy5wX2Rlc2NyaXB0aW9uPy52YWx1ZSlcclxuICAgICAgICA/IHByb2R1Y3QuYXR0cmlidXRlVmFsdWVzLnBfZGVzY3JpcHRpb24udmFsdWUuam9pbihcIiwgXCIpXHJcbiAgICAgICAgOiB0eXBlb2YgcHJvZHVjdC5hdHRyaWJ1dGVWYWx1ZXM/LnBfZGVzY3JpcHRpb24/LnZhbHVlID09PSBcInN0cmluZ1wiXHJcbiAgICAgICAgICA/IHByb2R1Y3QuYXR0cmlidXRlVmFsdWVzLnBfZGVzY3JpcHRpb24udmFsdWVcclxuICAgICAgICAgIDogXCJcIik7XHJcblxyXG4gICAgY29uc3QgaW1hZ2UgPSBwcm9kdWN0LmltYWdlIHx8IHByb2R1Y3QuYXR0cmlidXRlVmFsdWVzPy5wX2ltYWdlPy52YWx1ZT8uZG93bmxvYWRMaW5rIHx8IFwiXCI7XHJcblxyXG4gICAgY29uc3QgcHJpY2UgPSB0eXBlb2YgcHJvZHVjdC5wcmljZSA9PT0gXCJudW1iZXJcIlxyXG4gICAgICA/IHByb2R1Y3QucHJpY2VcclxuICAgICAgOiBOdW1iZXIocHJvZHVjdC5wcmljZSkgfHwgMDtcclxuXHJcbiAgICByZXR1cm4geyBpZCwgdGl0bGUsIGRlc2NyaXB0aW9uLCBpbWFnZSwgcHJpY2UgfTtcclxuICB9KTtcclxufTtcclxuXHJcbi8vIOKchSBBZG1pbjogR2V0IFByb2R1Y3RzIG9mIFNwZWNpZmljIFNlbGxlclxyXG5leHBvcnQgY29uc3QgZ2V0UHJvZHVjdHNCeVNlbGxlcklkID0gYXN5bmMgKHNlbGxlcklkOiBzdHJpbmcpID0+IHtcclxuICBjb25zdCBhbGxDb29raWVzID0gYXdhaXQgY29va2llcygpO1xyXG4gIGNvbnN0IHJvbGUgPSBhbGxDb29raWVzLmdldChcInVzZXJSb2xlXCIpPy52YWx1ZTtcclxuXHJcbiAgaWYgKHJvbGUgIT09IFwiYWRtaW5cIikge1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiVW5hdXRob3JpemVkOiBBZG1pbnMgb25seS5cIik7XHJcbiAgfVxyXG5cclxuICBhd2FpdCBjb25uZWN0VG9EQigpO1xyXG5cclxuICByZXR1cm4gYXdhaXQgUHJvZHVjdC5maW5kKHsgc2VsbGVySWQgfSlcclxuICAgIC5wb3B1bGF0ZShcInNlbGxlcklkXCIsIFwibmFtZSBlbWFpbFwiKVxyXG4gICAgLnNvcnQoeyBjcmVhdGVkQXQ6IC0xIH0pXHJcbiAgICAubGVhbigpO1xyXG59O1xyXG5cclxuLy8g4pyFIEFkbWluOiBHZXQgQWxsIFNlbGxlcnNcclxuZXhwb3J0IGNvbnN0IGdldEFsbFNlbGxlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgY29uc3QgYWxsQ29va2llcyA9IGF3YWl0IGNvb2tpZXMoKTtcclxuICBjb25zdCByb2xlID0gYWxsQ29va2llcy5nZXQoXCJ1c2VyUm9sZVwiKT8udmFsdWU7XHJcblxyXG4gIGlmIChyb2xlICE9PSBcImFkbWluXCIpIHtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIlVuYXV0aG9yaXplZFwiKTtcclxuICB9XHJcblxyXG4gIGF3YWl0IGNvbm5lY3RUb0RCKCk7XHJcblxyXG4gIHJldHVybiBhd2FpdCBVc2VyLmZpbmQoeyByb2xlOiBcInNlbGxlclwiIH0pLnNlbGVjdChcIl9pZCBuYW1lIGVtYWlsXCIpLmxlYW4oKTtcclxufTtcclxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJ3U0FzR2EifQ==
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/(main)/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>HomePage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-client] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$productCatalog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/productCatalog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$action$2f$data$3a$059110__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/action/data:059110 [app-client] (ecmascript) <text/javascript>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
const categories = [
    {
        name: "Electronics",
        key: "electronics"
    },
    {
        name: "Fashion",
        key: "fashion"
    },
    {
        name: "Home & Kitchen",
        key: "homeandkitchen"
    },
    {
        name: "Books",
        key: "books"
    }
];
function HomePage() {
    _s();
    const [categoryProducts, setCategoryProducts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HomePage.useEffect": ()=>{
            const loadProducts = {
                "HomePage.useEffect.loadProducts": async ()=>{
                    const results = await Promise.all(categories.map({
                        "HomePage.useEffect.loadProducts": async (cat)=>{
                            const products = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$action$2f$data$3a$059110__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getProductsByCategory"])(cat.key);
                            return {
                                key: cat.name,
                                products
                            };
                        }
                    }["HomePage.useEffect.loadProducts"]));
                    const mapped = {};
                    for (const { key, products } of results){
                        mapped[key] = products;
                    }
                    setCategoryProducts(mapped);
                }
            }["HomePage.useEffect.loadProducts"];
            loadProducts();
        }
    }["HomePage.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-white",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
            className: "container mx-auto px-4 py-10 space-y-24",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative overflow-hidden rounded-2xl shadow-xl",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-full h-[400px] relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: "https://assets.entrepreneur.com/content/3x2/2000/20150812074510-Online-shopping.jpeg?format=pjeg&auto=webp&crop=16:9&width=1200",
                                    alt: "Hero Banner",
                                    className: "absolute inset-0 w-full h-full object-cover opacity-20 z-0",
                                    height: 400,
                                    width: 1200
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/page.tsx",
                                    lineNumber: 48,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute inset-0 flex flex-col justify-center items-center text-center px-6",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].h1, {
                                            className: "text-4xl font-extrabold mb-4 bg-gradient-to-r from-purple-600 via-pink-500 to-red-500 bg-clip-text text-transparent",
                                            initial: {
                                                opacity: 0,
                                                y: -20
                                            },
                                            animate: {
                                                opacity: 1,
                                                y: 0
                                            },
                                            transition: {
                                                duration: 0.8
                                            },
                                            children: "Welcome to Our Store!"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/page.tsx",
                                            lineNumber: 56,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-lg text-gray-700 mb-6 max-w-xl",
                                            children: "Explore the latest arrivals, top-selling items, and exclusive deals. Your perfect purchase is just a click away!"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/page.tsx",
                                            lineNumber: 64,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            className: "bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 hover:brightness-110 text-white px-6 py-2",
                                            children: [
                                                "Shop Now",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                    className: "ml-2 h-4 w-4"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(main)/page.tsx",
                                                    lineNumber: 70,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(main)/page.tsx",
                                            lineNumber: 68,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(main)/page.tsx",
                                    lineNumber: 55,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(main)/page.tsx",
                            lineNumber: 47,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(main)/page.tsx",
                        lineNumber: 46,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/(main)/page.tsx",
                    lineNumber: 45,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-2xl font-bold text-center mb-8",
                            children: "Top Categories"
                        }, void 0, false, {
                            fileName: "[project]/app/(main)/page.tsx",
                            lineNumber: 79,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-2 md:grid-cols-4 gap-6",
                            children: categories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-gray-100 p-6 rounded-xl shadow hover:shadow-md transition text-center font-semibold text-gray-700",
                                    children: cat.name
                                }, cat.name, false, {
                                    fileName: "[project]/app/(main)/page.tsx",
                                    lineNumber: 82,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/app/(main)/page.tsx",
                            lineNumber: 80,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(main)/page.tsx",
                    lineNumber: 78,
                    columnNumber: 9
                }, this),
                categories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$productCatalog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        title: cat.name,
                        products: categoryProducts[cat.name] || []
                    }, cat.name, false, {
                        fileName: "[project]/app/(main)/page.tsx",
                        lineNumber: 94,
                        columnNumber: 11
                    }, this)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    className: "text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-2xl font-bold mb-8",
                            children: "What Our Customers Say"
                        }, void 0, false, {
                            fileName: "[project]/app/(main)/page.tsx",
                            lineNumber: 103,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid gap-6 md:grid-cols-3",
                            children: [
                                {
                                    name: "Ravi Sharma",
                                    feedback: "Amazing quality and fast delivery. I’ll definitely shop again!"
                                },
                                {
                                    name: "Sneha Kapoor",
                                    feedback: "Great customer service and awesome product variety!"
                                },
                                {
                                    name: "Aditya Verma",
                                    feedback: "User-friendly website and smooth checkout process!"
                                }
                            ].map((review, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-gray-50 p-6 rounded-lg shadow border",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-gray-600 italic mb-4",
                                            children: review.feedback
                                        }, void 0, false, {
                                            fileName: "[project]/app/(main)/page.tsx",
                                            lineNumber: 120,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "font-semibold text-gray-800",
                                            children: [
                                                "— ",
                                                review.name
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(main)/page.tsx",
                                            lineNumber: 121,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, idx, true, {
                                    fileName: "[project]/app/(main)/page.tsx",
                                    lineNumber: 119,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/app/(main)/page.tsx",
                            lineNumber: 104,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(main)/page.tsx",
                    lineNumber: 102,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    className: "bg-gradient-to-r from-pink-100 to-purple-100 py-10 rounded-2xl shadow-inner text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-xl md:text-2xl font-bold mb-4",
                            children: "Stay Updated!"
                        }, void 0, false, {
                            fileName: "[project]/app/(main)/page.tsx",
                            lineNumber: 129,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-gray-700 mb-6",
                            children: "Subscribe to our newsletter and get the latest updates and deals."
                        }, void 0, false, {
                            fileName: "[project]/app/(main)/page.tsx",
                            lineNumber: 130,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                            className: "flex justify-center gap-4 flex-wrap",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "email",
                                    placeholder: "Enter your email",
                                    className: "px-4 py-2 rounded-md border w-64"
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/page.tsx",
                                    lineNumber: 134,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    className: "bg-purple-600 text-white px-6 py-2",
                                    children: "Subscribe"
                                }, void 0, false, {
                                    fileName: "[project]/app/(main)/page.tsx",
                                    lineNumber: 139,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(main)/page.tsx",
                            lineNumber: 133,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(main)/page.tsx",
                    lineNumber: 128,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(main)/page.tsx",
            lineNumber: 43,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(main)/page.tsx",
        lineNumber: 42,
        columnNumber: 5
    }, this);
}
_s(HomePage, "Damdq0oyXXmJDyAjd5EzR6ZfRZY=");
_c = HomePage;
var _c;
__turbopack_context__.k.register(_c, "HomePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=_085970c7._.js.map