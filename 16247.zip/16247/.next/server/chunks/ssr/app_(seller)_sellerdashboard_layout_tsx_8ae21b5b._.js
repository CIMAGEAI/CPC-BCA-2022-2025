module.exports = {

"[project]/app/(seller)/sellerdashboard/layout.tsx [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=app_%28seller%29_sellerdashboard_layout_tsx_8ae21b5b._.js.map