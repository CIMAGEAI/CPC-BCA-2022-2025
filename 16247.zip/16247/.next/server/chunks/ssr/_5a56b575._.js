module.exports = {

"[project]/action/data:262ee5 [app-ssr] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"7f2f73636b7e2e75d693b86d859a2586f757977ae2":"getProductById"},"action/product.actions.ts",""] */ __turbopack_context__.s({
    "getProductById": (()=>getProductById)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getProductById = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("7f2f73636b7e2e75d693b86d859a2586f757977ae2", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getProductById"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vcHJvZHVjdC5hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xyXG5cclxuaW1wb3J0IHsgY29ubmVjdFRvREIgfSBmcm9tIFwiQC9saWIvZGJcIjtcclxuaW1wb3J0IHsgUHJvZHVjdCB9IGZyb20gXCJAL21vZGVscy9wcm9kdWN0c1wiO1xyXG5pbXBvcnQgeyBVc2VyIH0gZnJvbSBcIkAvbW9kZWxzL3VzZXJcIjtcclxuaW1wb3J0IHsgY29va2llcyB9IGZyb20gXCJuZXh0L2hlYWRlcnNcIjtcclxuaW1wb3J0IGp3dCBmcm9tIFwianNvbndlYnRva2VuXCI7XHJcblxyXG4vLyBDb21tb24gdHlwZSBmb3IgY2xpZW50LXNhZmUgcHJvZHVjdHNcclxuZXhwb3J0IHR5cGUgUHJvZHVjdElucHV0ID0ge1xyXG4gIGlkOiBzdHJpbmc7XHJcbiAgdGl0bGU6IHN0cmluZztcclxuICBkZXNjcmlwdGlvbjogc3RyaW5nO1xyXG4gIHByaWNlOiBudW1iZXI7XHJcbiAgaW1hZ2U6IHN0cmluZztcclxufTtcclxuXHJcbi8vIERlY29kZWQgSldUIFRva2VuIFR5cGVcclxuaW50ZXJmYWNlIERlY29kZWRUb2tlbiB7XHJcbiAgX2lkOiBzdHJpbmc7XHJcbiAgcm9sZTogc3RyaW5nO1xyXG4gIGVtYWlsOiBzdHJpbmc7XHJcbn1cclxuXHJcbi8vIPCflJAgSldULWJhc2VkIGF1dGhlbnRpY2F0aW9uIChmb3IgYWRtaW4gZW5kcG9pbnRzKVxyXG5jb25zdCBnZXRDdXJyZW50VXNlciA9IGFzeW5jICgpOiBQcm9taXNlPERlY29kZWRUb2tlbiB8IG51bGw+ID0+IHtcclxuICBjb25zdCB0b2tlbiA9IChhd2FpdCBjb29raWVzKCkpLmdldChcImFjY2Vzc1Rva2VuXCIpPy52YWx1ZTtcclxuICBpZiAoIXRva2VuIHx8ICFwcm9jZXNzLmVudi5BQ0NFU1NfU0VDUkVUKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRlY29kZWQgPSBqd3QudmVyaWZ5KHRva2VuLCBwcm9jZXNzLmVudi5BQ0NFU1NfU0VDUkVUKSBhcyBEZWNvZGVkVG9rZW47XHJcbiAgICByZXR1cm4gZGVjb2RlZDtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxufTtcclxuXHJcbi8vIOKchSBDcmVhdGUgUHJvZHVjdCAoU2VsbGVyIG9ubHkpXHJcbmV4cG9ydCBjb25zdCBjcmVhdGVQcm9kdWN0ID0gYXN5bmMgKGZvcm1EYXRhOiBGb3JtRGF0YSkgPT4ge1xyXG4gIGNvbnN0IGFsbENvb2tpZXMgPSBhd2FpdCBjb29raWVzKCk7XHJcbiAgY29uc3Qgcm9sZSA9IGFsbENvb2tpZXMuZ2V0KFwidXNlclJvbGVcIik/LnZhbHVlO1xyXG4gIGNvbnN0IHNlbGxlcklkID0gYWxsQ29va2llcy5nZXQoXCJpZFwiKT8udmFsdWU7XHJcbmlmICghc2VsbGVySWQgfHwgKHJvbGUgIT09IFwic2VsbGVyXCIgJiYgcm9sZSAhPT0gXCJhZG1pblwiKSkge1xyXG4gIHRocm93IG5ldyBFcnJvcihcIlVuYXV0aG9yaXplZDogT25seSBzZWxsZXJzIG9yIGFkbWlucyBjYW4gY3JlYXRlIHByb2R1Y3RzLlwiKTtcclxufVxyXG5cclxuICBjb25zdCB0aXRsZSA9IGZvcm1EYXRhLmdldChcInRpdGxlXCIpIGFzIHN0cmluZztcclxuICBjb25zdCBwcmljZSA9IE51bWJlcihmb3JtRGF0YS5nZXQoXCJwcmljZVwiKSk7XHJcbiAgY29uc3QgZGVzY3JpcHRpb24gPSBmb3JtRGF0YS5nZXQoXCJkZXNjcmlwdGlvblwiKSBhcyBzdHJpbmc7XHJcbiAgY29uc3QgY2F0ZWdvcnkgPSBmb3JtRGF0YS5nZXQoXCJjYXRlZ29yeVwiKSBhcyBzdHJpbmc7XHJcbiAgY29uc3QgZmlsZSA9IGZvcm1EYXRhLmdldChcImltYWdlXCIpIGFzIEZpbGU7XHJcblxyXG4gIGNvbnN0IGJ1ZmZlciA9IGF3YWl0IGZpbGUuYXJyYXlCdWZmZXIoKTtcclxuICBjb25zdCBiYXNlNjQgPSBCdWZmZXIuZnJvbShidWZmZXIpLnRvU3RyaW5nKFwiYmFzZTY0XCIpO1xyXG4gIGNvbnN0IGltYWdlID0gYGRhdGE6JHtmaWxlLnR5cGV9O2Jhc2U2NCwke2Jhc2U2NH1gO1xyXG5cclxuICBhd2FpdCBjb25uZWN0VG9EQigpO1xyXG5cclxuICBjb25zdCBwcm9kdWN0ID0gbmV3IFByb2R1Y3QoeyB0aXRsZSwgcHJpY2UsIGRlc2NyaXB0aW9uLCBjYXRlZ29yeSwgaW1hZ2UsIHNlbGxlcklkIH0pO1xyXG4gIGF3YWl0IHByb2R1Y3Quc2F2ZSgpO1xyXG5cclxuICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcbn07XHJcblxyXG4vLyDinIUgU2VsbGVyOiBHZXQgVGhlaXIgUHJvZHVjdHNcclxuZXhwb3J0IGNvbnN0IGdldFNlbGxlclByb2R1Y3RzID0gYXN5bmMgKCkgPT4ge1xyXG4gIGNvbnN0IGFsbENvb2tpZXMgPSBhd2FpdCBjb29raWVzKCk7XHJcbiAgY29uc3Qgcm9sZSA9IGFsbENvb2tpZXMuZ2V0KFwidXNlclJvbGVcIik/LnZhbHVlO1xyXG4gIGNvbnN0IHNlbGxlcklkID0gYWxsQ29va2llcy5nZXQoXCJpZFwiKT8udmFsdWU7XHJcblxyXG4gIGlmICghcm9sZSB8fCAhc2VsbGVySWQpIHtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIlVuYXV0aG9yaXplZFwiKTtcclxuICB9XHJcblxyXG4gIGF3YWl0IGNvbm5lY3RUb0RCKCk7XHJcblxyXG4gIGNvbnN0IHF1ZXJ5ID0gcm9sZSA9PT0gXCJhZG1pblwiID8ge30gOiB7IHNlbGxlcklkIH07XHJcblxyXG4gIGNvbnN0IHByb2R1Y3RzID0gYXdhaXQgUHJvZHVjdC5maW5kKHF1ZXJ5KVxyXG4gICAgLnBvcHVsYXRlKFwic2VsbGVySWRcIiwgXCJuYW1lIGVtYWlsXCIpXHJcbiAgICAuc29ydCh7IGNyZWF0ZWRBdDogLTEgfSlcclxuICAgIC5sZWFuKCk7XHJcblxyXG4gIHJldHVybiBwcm9kdWN0cztcclxufTtcclxuXHJcbi8vIOKchSBBZG1pbiBvbmx5OiBHZXQgQWxsIFByb2R1Y3RzXHJcbmV4cG9ydCBjb25zdCBnZXRBbGxQcm9kdWN0cyA9IGFzeW5jICgpID0+IHtcclxuICBjb25zdCB1c2VyID0gYXdhaXQgZ2V0Q3VycmVudFVzZXIoKTtcclxuICBpZiAoIXVzZXIgfHwgdXNlci5yb2xlICE9PSBcImFkbWluXCIpIHtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIlVuYXV0aG9yaXplZDogQWRtaW5zIG9ubHkuXCIpO1xyXG4gIH1cclxuXHJcbiAgYXdhaXQgY29ubmVjdFRvREIoKTtcclxuXHJcbiAgcmV0dXJuIGF3YWl0IFByb2R1Y3QuZmluZCgpXHJcbiAgICAucG9wdWxhdGUoXCJzZWxsZXJJZFwiLCBcIm5hbWUgZW1haWxcIilcclxuICAgIC5zb3J0KHsgY3JlYXRlZEF0OiAtMSB9KVxyXG4gICAgLmxlYW4oKTtcclxufTtcclxuXHJcbi8vIOKchSBQdWJsaWM6IEdldCBQcm9kdWN0cyBieSBDYXRlZ29yeSAoQ2xpZW50IHVzZXMgdGhpcylcclxuZXhwb3J0IGNvbnN0IGdldFByb2R1Y3RzQnlDYXRlZ29yeSA9IGFzeW5jIChjYXRlZ29yeTogc3RyaW5nKTogUHJvbWlzZTxQcm9kdWN0SW5wdXRbXT4gPT4ge1xyXG4gIGF3YWl0IGNvbm5lY3RUb0RCKCk7XHJcblxyXG4gIGNvbnN0IHByb2R1Y3RzID0gYXdhaXQgUHJvZHVjdC5maW5kKHsgY2F0ZWdvcnkgfSkuc29ydCh7IGNyZWF0ZWRBdDogLTEgfSkubGVhbigpO1xyXG5cclxuICByZXR1cm4gcHJvZHVjdHMubWFwKChwcm9kdWN0KSA9PiB7XHJcbiAgICBjb25zdCBpZCA9IHByb2R1Y3QuX2lkPy50b1N0cmluZz8uKCkgfHwgXCJ1bmtub3duXCI7XHJcblxyXG4gICAgY29uc3QgdGl0bGUgPSBwcm9kdWN0LnRpdGxlIHx8IHByb2R1Y3QuYXR0cmlidXRlVmFsdWVzPy5wX3RpdGxlPy52YWx1ZSB8fCBcIlVudGl0bGVkXCI7XHJcblxyXG4gICAgY29uc3QgZGVzY3JpcHRpb24gPSBwcm9kdWN0LmRlc2NyaXB0aW9uXHJcbiAgICAgID8/IChBcnJheS5pc0FycmF5KHByb2R1Y3QuYXR0cmlidXRlVmFsdWVzPy5wX2Rlc2NyaXB0aW9uPy52YWx1ZSlcclxuICAgICAgICA/IHByb2R1Y3QuYXR0cmlidXRlVmFsdWVzLnBfZGVzY3JpcHRpb24udmFsdWUuam9pbihcIiwgXCIpXHJcbiAgICAgICAgOiB0eXBlb2YgcHJvZHVjdC5hdHRyaWJ1dGVWYWx1ZXM/LnBfZGVzY3JpcHRpb24/LnZhbHVlID09PSBcInN0cmluZ1wiXHJcbiAgICAgICAgICA/IHByb2R1Y3QuYXR0cmlidXRlVmFsdWVzLnBfZGVzY3JpcHRpb24udmFsdWVcclxuICAgICAgICAgIDogXCJcIik7XHJcblxyXG4gICAgY29uc3QgaW1hZ2UgPSBwcm9kdWN0LmltYWdlIHx8IHByb2R1Y3QuYXR0cmlidXRlVmFsdWVzPy5wX2ltYWdlPy52YWx1ZT8uZG93bmxvYWRMaW5rIHx8IFwiXCI7XHJcblxyXG4gICAgY29uc3QgcHJpY2UgPSB0eXBlb2YgcHJvZHVjdC5wcmljZSA9PT0gXCJudW1iZXJcIlxyXG4gICAgICA/IHByb2R1Y3QucHJpY2VcclxuICAgICAgOiBOdW1iZXIocHJvZHVjdC5wcmljZSkgfHwgMDtcclxuXHJcbiAgICByZXR1cm4geyBpZCwgdGl0bGUsIGRlc2NyaXB0aW9uLCBpbWFnZSwgcHJpY2UgfTtcclxuICB9KTtcclxufTtcclxuXHJcbi8vIOKchSBBZG1pbjogR2V0IFByb2R1Y3RzIG9mIFNwZWNpZmljIFNlbGxlclxyXG5leHBvcnQgY29uc3QgZ2V0UHJvZHVjdHNCeVNlbGxlcklkID0gYXN5bmMgKHNlbGxlcklkOiBzdHJpbmcpID0+IHtcclxuICBjb25zdCBhbGxDb29raWVzID0gYXdhaXQgY29va2llcygpO1xyXG4gIGNvbnN0IHJvbGUgPSBhbGxDb29raWVzLmdldChcInVzZXJSb2xlXCIpPy52YWx1ZTtcclxuXHJcbiAgaWYgKHJvbGUgIT09IFwiYWRtaW5cIikge1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiVW5hdXRob3JpemVkOiBBZG1pbnMgb25seS5cIik7XHJcbiAgfVxyXG5cclxuICBhd2FpdCBjb25uZWN0VG9EQigpO1xyXG5cclxuICByZXR1cm4gYXdhaXQgUHJvZHVjdC5maW5kKHsgc2VsbGVySWQgfSlcclxuICAgIC5wb3B1bGF0ZShcInNlbGxlcklkXCIsIFwibmFtZSBlbWFpbFwiKVxyXG4gICAgLnNvcnQoeyBjcmVhdGVkQXQ6IC0xIH0pXHJcbiAgICAubGVhbigpO1xyXG59O1xyXG5cclxuLy8g4pyFIEFkbWluOiBHZXQgQWxsIFNlbGxlcnNcclxuZXhwb3J0IGNvbnN0IGdldEFsbFNlbGxlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgY29uc3QgYWxsQ29va2llcyA9IGF3YWl0IGNvb2tpZXMoKTtcclxuICBjb25zdCByb2xlID0gYWxsQ29va2llcy5nZXQoXCJ1c2VyUm9sZVwiKT8udmFsdWU7XHJcblxyXG4gIGlmIChyb2xlICE9PSBcImFkbWluXCIpIHtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIlVuYXV0aG9yaXplZFwiKTtcclxuICB9XHJcblxyXG4gIGF3YWl0IGNvbm5lY3RUb0RCKCk7XHJcblxyXG4gIHJldHVybiBhd2FpdCBVc2VyLmZpbmQoeyByb2xlOiBcInNlbGxlclwiIH0pLnNlbGVjdChcIl9pZCBuYW1lIGVtYWlsXCIpLmxlYW4oKTtcclxufTtcclxuXHJcblxyXG5cclxuLy8g4pyFIFB1YmxpYyBvciBBdXRoZW50aWNhdGVkOiBHZXQgUHJvZHVjdCBCeSBJRFxyXG5leHBvcnQgY29uc3QgZ2V0UHJvZHVjdEJ5SWQgPSBhc3luYyAocHJvZHVjdElkOiBzdHJpbmcpOiBQcm9taXNlPFByb2R1Y3RJbnB1dCB8IG51bGw+ID0+IHtcclxuICBhd2FpdCBjb25uZWN0VG9EQigpO1xyXG5cclxuICBjb25zdCBwcm9kdWN0ID0gYXdhaXQgUHJvZHVjdC5maW5kQnlJZChwcm9kdWN0SWQpLmxlYW4oKTtcclxuICBpZiAoIXByb2R1Y3QpIHJldHVybiBudWxsO1xyXG5cclxuICBjb25zdCBpZCA9IHByb2R1Y3QuX2lkPy50b1N0cmluZz8uKCkgfHwgXCJ1bmtub3duXCI7XHJcblxyXG4gIGNvbnN0IHRpdGxlID0gcHJvZHVjdC50aXRsZSB8fCBwcm9kdWN0LmF0dHJpYnV0ZVZhbHVlcz8ucF90aXRsZT8udmFsdWUgfHwgXCJVbnRpdGxlZFwiO1xyXG5cclxuICBjb25zdCBkZXNjcmlwdGlvbiA9IHByb2R1Y3QuZGVzY3JpcHRpb25cclxuICAgID8/IChBcnJheS5pc0FycmF5KHByb2R1Y3QuYXR0cmlidXRlVmFsdWVzPy5wX2Rlc2NyaXB0aW9uPy52YWx1ZSlcclxuICAgICAgPyBwcm9kdWN0LmF0dHJpYnV0ZVZhbHVlcy5wX2Rlc2NyaXB0aW9uLnZhbHVlLmpvaW4oXCIsIFwiKVxyXG4gICAgICA6IHR5cGVvZiBwcm9kdWN0LmF0dHJpYnV0ZVZhbHVlcz8ucF9kZXNjcmlwdGlvbj8udmFsdWUgPT09IFwic3RyaW5nXCJcclxuICAgICAgICA/IHByb2R1Y3QuYXR0cmlidXRlVmFsdWVzLnBfZGVzY3JpcHRpb24udmFsdWVcclxuICAgICAgICA6IFwiXCIpO1xyXG5cclxuICBjb25zdCBpbWFnZSA9IHByb2R1Y3QuaW1hZ2UgfHwgcHJvZHVjdC5hdHRyaWJ1dGVWYWx1ZXM/LnBfaW1hZ2U/LnZhbHVlPy5kb3dubG9hZExpbmsgfHwgXCJcIjtcclxuXHJcbiAgY29uc3QgcHJpY2UgPSB0eXBlb2YgcHJvZHVjdC5wcmljZSA9PT0gXCJudW1iZXJcIlxyXG4gICAgPyBwcm9kdWN0LnByaWNlXHJcbiAgICA6IE51bWJlcihwcm9kdWN0LnByaWNlKSB8fCAwO1xyXG5cclxuICByZXR1cm4geyBpZCwgdGl0bGUsIGRlc2NyaXB0aW9uLCBpbWFnZSwgcHJpY2UgfTtcclxufTtcclxuXHJcblxyXG5cclxuXHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiaVNBbUthIn0=
}}),
"[project]/app/(main)/product/[id]/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ProductDetailPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$action$2f$data$3a$262ee5__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/action/data:262ee5 [app-ssr] (ecmascript) <text/javascript>");
"use client";
;
;
;
function ProductDetailPage({ productId }) {
    const [product, setProduct] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const fetchProduct = async ()=>{
            const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$action$2f$data$3a$262ee5__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getProductById"])(productId);
            setProduct(data);
        };
        fetchProduct();
    }, [
        productId
    ]);
    if (!product) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: "Loading..."
    }, void 0, false, {
        fileName: "[project]/app/(main)/product/[id]/page.tsx",
        lineNumber: 16,
        columnNumber: 24
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                children: product.title
            }, void 0, false, {
                fileName: "[project]/app/(main)/product/[id]/page.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                src: product.image,
                alt: product.title,
                width: 200
            }, void 0, false, {
                fileName: "[project]/app/(main)/product/[id]/page.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: product.description
            }, void 0, false, {
                fileName: "[project]/app/(main)/product/[id]/page.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: [
                    "Price: ₹",
                    product.price
                ]
            }, void 0, true, {
                fileName: "[project]/app/(main)/product/[id]/page.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(main)/product/[id]/page.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=_5a56b575._.js.map