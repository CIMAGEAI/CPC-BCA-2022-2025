<!DOCTYPE html>
<html>
<head>
    <title>Online Marriage Regitration System :: Home Page</title>

    <script type="application/x-javascript">
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);
        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>

    <!--//Meta tag Keywords -->
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <link rel="stylesheet" href="css/font-awesome.css">
    <link href="//fonts.googleapis.com/css?family=Basic" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Titillium+Web" rel="stylesheet">

    <style>
        body {
            font-family: 'Titillium Web', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        .button-link {
            display: inline-block;
            padding: 12px 25px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 20px;
            margin: 10px;
            transition: background-color 0.3s ease;
            color: white;
        }

        .admin-btn {
            background-color: #dc3545; /* Red */
        }

        .admin-btn:hover {
			background-color: #a71d2a;
        }

        .user-btn {
            background-color: #007BFF; /* Blue */
        }

        .user-btn:hover {
            background-color: #0056b3;
        }

        .map-container {
            margin-top: 20px;
            width: 100%;
            height: 300px;
        }

        .map-container iframe {
            width: 100%;
            height: 100%;
            border: 0;
        }

        footer {
            background: #222;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        .footer-details {
            margin-top: 15px;
            font-size: 16px;
        }

        .store-icons {
            margin: 15px 0;
        }

        .store-icons img {
            height: 40px;
            margin: 0 10px;
            vertical-align: middle;
        }

        .contact-info {
            margin-top: 10px;
            font-size: 15px;
            line-height: 1.6;
        }
    </style>
</head>

<body>
    <div class="w3ls-icons" style="text-align: center;">
        <a href="admin/login.php" class="button-link admin-btn">Admin</a>
        <a href="user/login.php" class="button-link user-btn">User</a>
    </div>

    <div class="w3ls-head">
        <h1>Online Marriage Regitration System</h1>
    </div>

    <div class="w3ls-content">
        <div class="w3ls-headding">
            <h2><img src="images/marriagedp.jpg"></h2>
            <p>We are launching the most awesome site ever. It's gonna be legendary</p>
        </div>
    </div>
<footer>
    <div style="max-width: 1200px; margin: auto; padding: 10px;">
        <!-- Company Info -->
        <div class="footer-details">
            <strong style="font-size: 18px;">© 2020 Online Marriage Registration System</strong><br>
            <span style="font-size: 14px;">All Rights Reserved</span>
        </div>

        <!-- Contact Info -->
        <div class="contact-info" style="margin-top: 15px;">
            <p><i class="fa fa-phone" aria-hidden="true"></i> Contact: +91-9876543210</p>
            <p><i class="fa fa-envelope" aria-hidden="true"></i> Email: <a href="mailto:support@marriageregistration.com" style="color: #fff; text-decoration: underline;">support@marriageregistration.com</a></p>
        </div>

        <!-- Map Embed -->
        <div class="map-container">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3609.415296544142!2d78.0488002148628!3d25.43714698377421!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3977761cdcf3e8a9%3A0xa816bf77c3fba69d!2sRegistrar%20Office!5e0!3m2!1sen!2sin!4v1597743912234!5m2!1sen!2sin"
                allowfullscreen=""
                loading="lazy">
            </iframe>
        </div>
    </div>
</footer>

</body>
</html>
