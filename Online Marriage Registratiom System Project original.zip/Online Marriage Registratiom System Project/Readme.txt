How to run the Online Marriage Registration System using PHP and MySQL

1.Download the zip file

2.Extract the file and copy omrs folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5.Create a database with name omrsdb

6.Import omrsdb.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/omrs


User Credential
Username: 1234567890
Password: Test@123

Admin Credential
Username: admin
Password: Test@123